package geometry;

import java.util.Objects;
import java.io.Serializable;

public record Point2(double x, double y) implements Serializable {
    public Point2 {
        if (!Double.isFinite(x) || !Double.isFinite(y)) {
            throw new IllegalArgumentException("Invalid coordinates");
        }
    }

    public double distance(Point2 other) {
        Objects.requireNonNull(other);
        return Math.hypot(x - other.x(), y - other.y());
    }

    public Point2 translated(double dx, double dy) {
        return new Point2(x + dx, y + dy);
    }

    public Point2 midpoint(Point2 other) {
        Objects.requireNonNull(other);
        return new Point2(x / 2 + other.x() / 2, y / 2 + other.y() / 2);
    }

    public Point2 rotated(double radians, Point2 pivot) {
        Objects.requireNonNull(pivot);
        if (!Double.isFinite(radians)) {
            throw new IllegalArgumentException("Invalid angle");
        }
        if (radians == 0 || equals(pivot)) {
            return this;
        }
        double dx = x - pivot.x();
        double dy = y - pivot.y();
        if (!Double.isFinite(dx) || !Double.isFinite(dy)) {
            throw new IllegalArgumentException("Invalid coordinates");
        }
        double cosine = Math.cos(radians);
        double sine = Math.sin(radians);
        return new Point2(pivot.x() + dx * cosine - dy * sine,
                          pivot.y() + dx * sine + dy * cosine);
    }
}