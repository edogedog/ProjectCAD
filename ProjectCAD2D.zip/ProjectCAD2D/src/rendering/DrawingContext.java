package rendering;

import geometry.Point2;
import java.awt.Color;
import java.util.List;

public interface DrawingContext {

    void line(Point2 start, Point2 end);

    void circle(Point2 center, double radius);

    void polygon(List<Point2> vertices);

    default void circle(Point2 center,
                        double radius,
                        Color color) {

        circle(center, radius);
    }

    default void line(Point2 start,
                      Point2 end,
                      Color color) {

        line(start, end);
    }

    default void polygon(List<Point2> vertices,
                         Color color) {

        polygon(vertices);
    }

    default void circle(Point2 center,
                        double radius,
                        Color color,
                        float thickness) {

        circle(center, radius, color);
    }

    default void line(Point2 start,
                      Point2 end,
                      Color color,
                      float thickness) {

        line(start, end, color);
    }

    default void polygon(List<Point2> vertices,
                         Color color,
                         float thickness) {

        polygon(vertices, color);
    }
}