
package rendering;

import geometry.Point2;
import java.awt.Color;
import java.util.List;

public interface DrawingContext {

    void line(Point2 start, Point2 end);

    void circle(Point2 center, double radius);

    default void circle(Point2 center, double radius, Color color) {
        circle(center, radius);
    }

    void polygon(List<Point2> vertices);
}
