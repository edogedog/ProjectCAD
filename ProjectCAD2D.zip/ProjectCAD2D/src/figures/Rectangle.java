package figures;

import java.util.List;
import java.util.Objects;
import java.awt.Color;
import geometry.Point2;
import rendering.DrawingContext;

public final class Rectangle implements Figure {

    private Color color = Color.BLACK;
    private float thickness = 1.0f;

    private Point2 topLeft;
    private Point2 topRight;
    private Point2 bottomLeft;
    private Point2 bottomRight;

    public Rectangle(Point2 topLeft, double width, double height) {

        this.topLeft = Objects.requireNonNull(topLeft);

        if (width <= 0 || !Double.isFinite(width)) {
            throw new IllegalArgumentException("Invalid width");
        }

        if (height <= 0 || !Double.isFinite(height)) {
            throw new IllegalArgumentException("Invalid height");
        }

        if (!Double.isFinite(topLeft.x() + width) ||
            !Double.isFinite(topLeft.y() + height)) {
            throw new IllegalArgumentException();
        }

        topRight = new Point2(
            topLeft.x() + width,
            topLeft.y()
        );

        bottomLeft = new Point2(
            topLeft.x(),
            topLeft.y() + height
        );

        bottomRight = new Point2(
            topLeft.x() + width,
            topLeft.y() + height
        );
    }

    @Override
    public void draw(DrawingContext context) {

        context.polygon(
            List.of(topLeft, topRight, bottomRight, bottomLeft),
            color,
            thickness
        );
    }

    @Override
    public Point2 getCenter() {

        return new Point2(
            topLeft.x() / 2 + bottomRight.x() / 2,
            topLeft.y() / 2 + bottomRight.y() / 2
        );
    }

    @Override
    public void move(double dx, double dy) {

        Point2 newTL = topLeft.translated(dx, dy);
        Point2 newTR = topRight.translated(dx, dy);
        Point2 newBL = bottomLeft.translated(dx, dy);
        Point2 newBR = bottomRight.translated(dx, dy);

        validate(newTL, newTR, newBL, newBR);

        topLeft = newTL;
        topRight = newTR;
        bottomLeft = newBL;
        bottomRight = newBR;
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {

        Objects.requireNonNull(pivot);

        if (!Double.isFinite(radians)) {
            throw new IllegalArgumentException();
        }

        Point2 newTL = topLeft.rotated(radians, pivot);
        Point2 newTR = topRight.rotated(radians, pivot);
        Point2 newBL = bottomLeft.rotated(radians, pivot);
        Point2 newBR = bottomRight.rotated(radians, pivot);

        validate(newTL, newTR, newBL, newBR);

        topLeft = newTL;
        topRight = newTR;
        bottomLeft = newBL;
        bottomRight = newBR;
    }

    @Override
    public void scale(double factor, Point2 pivot) {

        Objects.requireNonNull(pivot);

        if (!Double.isFinite(factor) || factor <= 0) {
            throw new IllegalArgumentException();
        }

        Point2 newTL = scalePoint(topLeft, pivot, factor);
        Point2 newTR = scalePoint(topRight, pivot, factor);
        Point2 newBL = scalePoint(bottomLeft, pivot, factor);
        Point2 newBR = scalePoint(bottomRight, pivot, factor);

        validate(newTL, newTR, newBL, newBR);

        topLeft = newTL;
        topRight = newTR;
        bottomLeft = newBL;
        bottomRight = newBR;
    }

    private Point2 scalePoint(Point2 point,
                              Point2 pivot,
                              double factor) {

        double newX =
            pivot.x() + (point.x() - pivot.x()) * factor;

        double newY =
            pivot.y() + (point.y() - pivot.y()) * factor;

        return new Point2(newX, newY);
    }

    private void validate(Point2... points) {

        for (Point2 point : points) {

            if (!Double.isFinite(point.x()) ||
                !Double.isFinite(point.y())) {

                throw new IllegalArgumentException();
            }
        }
    }

    @Override
    public Color getColor() {
        return color;
    }

    @Override
    public void setColor(Color color) {
        this.color = Objects.requireNonNull(color);
    }

    @Override
    public float getThickness() {
        return thickness;
    }

    @Override
    public void setThickness(float thickness) {

        if (!Float.isFinite(thickness) || thickness <= 0) {
            throw new IllegalArgumentException();
        }

        this.thickness = thickness;
    }
}