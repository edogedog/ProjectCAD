package figures;

import java.util.Objects;
import java.awt.Color;
import geometry.Point2;
import rendering.DrawingContext;

public final class Square implements Figure {

    private final Rectangle rectangle;

    public Square(Point2 topLeft, double side) {

        Objects.requireNonNull(topLeft);

        if (!Double.isFinite(side) || side <= 0) {
            throw new IllegalArgumentException("Invalid side");
        }

        rectangle = new Rectangle(topLeft, side, side);
    }

    @Override
    public void draw(DrawingContext context) {
        rectangle.draw(context);
    }

    @Override
    public Point2 getCenter() {
        return rectangle.getCenter();
    }

    @Override
    public void move(double dx, double dy) {
        rectangle.move(dx, dy);
    }

    @Override
    public void rotate(double radians) {
        rectangle.rotate(radians);
    }

    @Override
    public void rotate(double radians, Point2 pivot) {
        rectangle.rotate(radians, pivot);
    }

    @Override
    public void scale(double factor, Point2 pivot) {
        rectangle.scale(factor, pivot);
    }

    @Override
    public Color getColor() {
        return rectangle.getColor();
    }

    @Override
    public void setColor(Color color) {
        rectangle.setColor(color);
    }

    @Override
    public float getThickness() {
        return rectangle.getThickness();
    }

    @Override
    public void setThickness(float thickness) {
        rectangle.setThickness(thickness);
    }
}