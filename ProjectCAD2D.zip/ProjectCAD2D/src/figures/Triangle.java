package figures;

import java.util.Objects;
import java.util.List;
import java.awt.Color;
import geometry.Point2;
import rendering.DrawingContext;

public final class Triangle implements Figure {

    private Color color = Color.BLACK;
    private float thickness = 1.0f;

    private Point2 a;
    private Point2 b;
    private Point2 c;

    public Triangle(Point2 topLeft, double side) {

        Objects.requireNonNull(topLeft);

        if (!Double.isFinite(side) || side <= 0) {
            throw new IllegalArgumentException();
        }

        double x = topLeft.x();
        double y = topLeft.y();

        a = new Point2(x + side / 2, y);
        b = new Point2(x, y + side);
        c = new Point2(x + side, y + side);
    }

    @Override
    public void draw(DrawingContext context) {

        context.line(a, b, color, thickness);
        context.line(b, c, color, thickness);
        context.line(c, a, color, thickness);
    }

    @Override
    public Point2 getCenter() {

        return new Point2(
            (a.x() + b.x() + c.x()) / 3,
            (a.y() + b.y() + c.y()) / 3
        );
    }

    @Override
    public void move(double dx, double dy) {

        Point2 newA = a.translated(dx, dy);
        Point2 newB = b.translated(dx, dy);
        Point2 newC = c.translated(dx, dy);

        a = newA;
        b = newB;
        c = newC;
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {

        Objects.requireNonNull(pivot);

        if (!Double.isFinite(radians)) {
            throw new IllegalArgumentException();
        }

        Point2 newA = rotatePoint(a, pivot, radians);
        Point2 newB = rotatePoint(b, pivot, radians);
        Point2 newC = rotatePoint(c, pivot, radians);

        a = newA;
        b = newB;
        c = newC;
    }

    private Point2 rotatePoint(Point2 point,
                               Point2 pivot,
                               double angle) {

        double dx = point.x() - pivot.x();
        double dy = point.y() - pivot.y();

        double cos = Math.cos(angle);
        double sin = Math.sin(angle);

        return new Point2(
            pivot.x() + dx * cos - dy * sin,
            pivot.y() + dx * sin + dy * cos
        );
    }

    @Override
    public void scale(double factor, Point2 pivot) {

        Objects.requireNonNull(pivot);

        if (!Double.isFinite(factor) || factor <= 0) {
            throw new IllegalArgumentException();
        }

        Point2 newA = scalePoint(a, pivot, factor);
        Point2 newB = scalePoint(b, pivot, factor);
        Point2 newC = scalePoint(c, pivot, factor);

        for (Point2 point : List.of(newA, newB, newC)) {

            if (!Double.isFinite(point.x()) ||
                !Double.isFinite(point.y())) {

                throw new IllegalArgumentException();
            }
        }

        a = newA;
        b = newB;
        c = newC;
    }

    private Point2 scalePoint(Point2 point,
                              Point2 pivot,
                              double factor) {

        double newX =
            pivot.x() + (point.x() - pivot.x()) * factor;

        double newY =
            pivot.y() + (point.y() - pivot.y()) * factor;

        return new Point2(newX, newY);
    }

    @Override
    public Color getColor() {
        return color;
    }

    @Override
    public void setColor(Color color) {
        this.color = Objects.requireNonNull(color);
    }

    @Override
    public float getThickness() {
        return thickness;
    }

    @Override
    public void setThickness(float thickness) {

        if (!Float.isFinite(thickness) || thickness <= 0) {
            throw new IllegalArgumentException();
        }

        this.thickness = thickness;
    }
}