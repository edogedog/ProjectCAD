
package figures;

import java.util.Objects;
import java.util.List;
import geometry.Point2;
import rendering.DrawingContext;

public final class Triangle implements Figure {

    private Point2 a;
    private Point2 b;
    private Point2 c;

    public Triangle(Point2 topLeft, double side) {
        Objects.requireNonNull(topLeft);

        if (!Double.isFinite(side) || side <= 0) {
            throw new IllegalArgumentException("Invalid side");
        }

        double x = topLeft.x();
        double y = topLeft.y();

        a = new Point2(x + side / 2, y);
        b = new Point2(x, y + side);
        c = new Point2(x + side, y + side);
    }

    @Override
    public void draw(DrawingContext context) {
        context.line(a, b);
        context.line(b, c);
        context.line(c, a);
    }

    @Override
    public Point2 getCenter() {
        return new Point2(
            (a.x() + b.x() + c.x()) / 3,
            (a.y() + b.y() + c.y()) / 3
        );
    }

    @Override
    public void move(double dx, double dy) {
        a = new Point2(a.x() + dx, a.y() + dy);
        b = new Point2(b.x() + dx, b.y() + dy);
        c = new Point2(c.x() + dx, c.y() + dy);
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {
        Objects.requireNonNull(pivot);

        a = rotatePoint(a, pivot, radians);
        b = rotatePoint(b, pivot, radians);
        c = rotatePoint(c, pivot, radians);
    }

    private Point2 rotatePoint(Point2 p, Point2 pivot, double angle) {
        double dx = p.x() - pivot.x();
        double dy = p.y() - pivot.y();

        double cos = Math.cos(angle);
        double sin = Math.sin(angle);

        return new Point2(
            pivot.x() + dx * cos - dy * sin,
            pivot.y() + dx * sin + dy * cos
        );
    }
    @Override
    public void scale(double factor, Point2 pivot) {
        Objects.requireNonNull(pivot);

        if (!Double.isFinite(factor) || factor <= 0) {
            throw new IllegalArgumentException("Invalid factor");
        }

        Point2 newA = scalePoint(a, pivot, factor);
        Point2 newB = scalePoint(b, pivot, factor);
        Point2 newC = scalePoint(c, pivot, factor);

        // Kontrollera innan vi ändrar något
        for (Point2 p : List.of(newA, newB, newC)) {
            if (!Double.isFinite(p.x()) || !Double.isFinite(p.y())) {
                throw new IllegalArgumentException("Invalid coordinates");
            }
        }

        a = newA;
        b = newB;
        c = newC;
    }

    private Point2 scalePoint(Point2 point, Point2 pivot, double factor) {
        double newX = pivot.x() + (point.x() - pivot.x()) * factor;
        double newY = pivot.y() + (point.y() - pivot.y()) * factor;

        return new Point2(newX, newY);
    }
}
