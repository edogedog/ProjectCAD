package figures;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Objects;
import java.awt.Color;

import geometry.Point2;
import geometry.TransformChecks;
import rendering.DrawingContext;

public final class CompositeFigure implements Figure {

    private final List<Figure> children;

    public CompositeFigure(List<Figure> children) {

        Objects.requireNonNull(children);

        this.children = List.copyOf(children);

        IdentityHashMap<Figure, Boolean> seen =
            new IdentityHashMap<>();

        for (Figure figure : this.children) {
            checkUnique(figure, seen);
        }
    }

    private static void checkUnique(
            Figure figure,
            IdentityHashMap<Figure, Boolean> seen) {

        Objects.requireNonNull(figure);

        if (seen.put(figure, Boolean.TRUE) != null) {
            throw new IllegalArgumentException("Duplicate figure");
        }

        for (Figure child : figure.parts()) {
            checkUnique(child, seen);
        }
    }

    @Override
    public List<Figure> parts() {
        return children;
    }

    @Override
    public void draw(DrawingContext context) {

        Objects.requireNonNull(context);

        for (Figure figure : children) {
            figure.draw(context);
        }
    }

    @Override
    public Point2 getCenter() {

        if (children.isEmpty()) {
            return new Point2(0, 0);
        }

        double x = 0;
        double y = 0;
        int count = children.size();

        for (Figure figure : children) {

            Point2 center = figure.getCenter();

            x += center.x() / count;
            y += center.y() / count;
        }

        return new Point2(x, y);
    }

    @Override
    public void move(double dx, double dy) {

        TransformChecks.translation(this, dx, dy);

        for (Figure figure : children) {
            figure.move(dx, dy);
        }
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {

        Objects.requireNonNull(pivot);

        TransformChecks.rotation(this, radians, pivot);

        for (Figure figure : children) {
            figure.rotate(radians, pivot);
        }
    }

    @Override
    public void scale(double factor, Point2 pivot) {

        Objects.requireNonNull(pivot);

        if (!Double.isFinite(factor) || factor <= 0) {
            throw new IllegalArgumentException();
        }

        for (Figure child : children) {
            child.scale(factor, pivot);
        }
    }

    @Override
    public Color getColor() {

        if (children.isEmpty()) {
            return Color.BLACK;
        }

        return children.get(0).getColor();
    }

    @Override
    public void setColor(Color color) {

        Objects.requireNonNull(color);

        for (Figure child : children) {
            child.setColor(color);
        }
    }

    @Override
    public float getThickness() {

        if (children.isEmpty()) {
            return 1.0f;
        }

        return children.get(0).getThickness();
    }

    @Override
    public void setThickness(float thickness) {

        if (!Float.isFinite(thickness) || thickness <= 0) {
            throw new IllegalArgumentException();
        }

        for (Figure child : children) {
            child.setThickness(thickness);
        }
    }
}