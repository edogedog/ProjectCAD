package figures;

import geometry.Point2;
import java.util.List;
import java.awt.Color;
import java.io.Serializable;

public interface Figure extends Drawable, Movable, Rotatable, Serializable {

    Point2 getCenter();

    Color getColor();
    void setColor(Color color);

    float getThickness();
    void setThickness(float thickness);

    default List<Figure> parts() {
        return List.of();
    }

    void scale(double factor, Point2 pivot);
}