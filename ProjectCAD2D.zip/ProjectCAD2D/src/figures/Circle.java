
package figures;

import java.util.Objects;
import java.awt.Color;

import geometry.Point2;
import rendering.DrawingContext;

public final class Circle implements Figure {

    private final double radius;
    private Point2 center;
    private Color color;

    public Circle(Point2 center, double radius) {
        this(center, radius, Color.BLACK);
    }

    public Circle(Point2 center, double radius, Color color) {
        this.center = Objects.requireNonNull(center, "Circle center");
        this.color = Objects.requireNonNull(color, "Circle color");

        if (radius <= 0) {
            throw new IllegalArgumentException("större än noll!");
        }

        if (!Double.isFinite(radius)) {
            throw new IllegalArgumentException("måste vara vanligt double");
        }

        this.radius = radius;
    }

    @Override
    public void draw(DrawingContext context) {
        context.circle(center, radius, color);
    }

    @Override
    public Point2 getCenter() {
        return new Point2(center.x(), center.y());
    }

    @Override
    public void move(double dx, double dy) {
        Point2 newCenter = center.translated(dx, dy);

        if (!Double.isFinite(newCenter.x()) ||
            !Double.isFinite(newCenter.y())) {
            throw new IllegalArgumentException();
        }

        center = newCenter;
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {
        Objects.requireNonNull(pivot, "pivot cant be null");

        if (!Double.isFinite(radians)) {
            throw new IllegalArgumentException("invalid angle");
        }

        Point2 newCenter = center.rotated(radians, pivot);

        if (!Double.isFinite(newCenter.x()) ||
            !Double.isFinite(newCenter.y())) {
            throw new IllegalArgumentException("invalid coordinates");
        }

        center = newCenter;
    }
}
