
package figures;

import java.util.Objects;
import geometry.Point2;
import rendering.DrawingContext;

public final class Line implements Figure {

    private Point2 start;
    private Point2 end;

    public Line(Point2 start, Point2 end) {
        this.start = Objects.requireNonNull(start);
        this.end = Objects.requireNonNull(end);

        if (!Double.isFinite(start.x()) ||
            !Double.isFinite(start.y()) ||
            !Double.isFinite(end.x()) ||
            !Double.isFinite(end.y()) ||
            start.distance(end) <= 0) {
            throw new IllegalArgumentException("Invalid line");
        }
    }

    @Override
    public void draw(DrawingContext context) {
        context.line(start, end);
    }

    @Override
    public Point2 getCenter() {
        return new Point2(
            start.x() / 2 + end.x() / 2,
            start.y() / 2 + end.y() / 2
        );
    }

    @Override
    public void move(double dx, double dy) {
        Point2 a = start.translated(dx, dy);
        Point2 b = end.translated(dx, dy);
        validate(a, b);
        start = a;
        end = b;
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {
        Objects.requireNonNull(pivot);

        if (!Double.isFinite(radians)) {
            throw new IllegalArgumentException("Invalid angle");
        }

        Point2 a = start.rotated(radians, pivot);
        Point2 b = end.rotated(radians, pivot);
        validate(a, b);
        start = a;
        end = b;
    }

    private void validate(Point2 a, Point2 b) {
        if (!Double.isFinite(a.x()) ||
            !Double.isFinite(a.y()) ||
            !Double.isFinite(b.x()) ||
            !Double.isFinite(b.y())) {
            throw new IllegalArgumentException("Invalid coordinates");
        }
    }
    @Override
    public void scale(double factor, Point2 pivot) {
        Objects.requireNonNull(pivot);

        if (!Double.isFinite(factor) || factor <= 0) {
            throw new IllegalArgumentException("Invalid factor");
        }

        Point2 newStart = scalePoint(start, pivot, factor);
        Point2 newEnd = scalePoint(end, pivot, factor);

        if (!Double.isFinite(newStart.x()) ||
            !Double.isFinite(newStart.y()) ||
            !Double.isFinite(newEnd.x()) ||
            !Double.isFinite(newEnd.y())) {
            throw new IllegalArgumentException("Invalid coordinates");
        }

        start = newStart;
        end = newEnd;
    }

    private Point2 scalePoint(Point2 point, Point2 pivot, double factor) {
        double x = pivot.x() + (point.x() - pivot.x()) * factor;
        double y = pivot.y() + (point.y() - pivot.y()) * factor;

        return new Point2(x, y);
    }
}
