package commands;

import java.util.IdentityHashMap;
import java.util.List;

import figures.Figure;
import model.DrawingDocument;

public final class ThicknessCommand implements Command {

    private final DrawingDocument document;

    private final IdentityHashMap<Figure, Float> previous =
        new IdentityHashMap<>();

    private final float thickness;

    public ThicknessCommand(DrawingDocument document,
                            List<Figure> figures,
                            float thickness) {

        if (!Float.isFinite(thickness) || thickness <= 0) {
            throw new IllegalArgumentException();
        }

        this.document = document;
        this.thickness = thickness;

        for (Figure figure : figures) {
            collect(figure);
        }
    }

    private void collect(Figure figure) {

        if (figure.parts().isEmpty()) {

            previous.put(figure, figure.getThickness());

        } else {

            for (Figure child : figure.parts()) {
                collect(child);
            }
        }
    }

    @Override
    public void execute() {

        for (Figure figure : previous.keySet()) {
            figure.setThickness(thickness);
        }

        document.changed();
    }

    @Override
    public void undo() {

        previous.forEach(Figure::setThickness);

        document.changed();
    }
}