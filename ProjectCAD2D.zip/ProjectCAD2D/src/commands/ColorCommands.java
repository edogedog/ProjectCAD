package commands;

import java.awt.Color;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Objects;

import figures.Figure;
import model.DrawingDocument;

public final class ColorCommand implements Command {

    private final DrawingDocument document;

    private final IdentityHashMap<Figure, Color> previous =
        new IdentityHashMap<>();

    private final Color color;

    public ColorCommand(DrawingDocument document,
                        List<Figure> figures,
                        Color color) {

        this.document = document;
        this.color = Objects.requireNonNull(color);

        for (Figure figure : figures) {
            collect(figure);
        }
    }

    private void collect(Figure figure) {

        if (figure.parts().isEmpty()) {

            previous.put(figure, figure.getColor());

        } else {

            for (Figure child : figure.parts()) {
                collect(child);
            }
        }
    }

    @Override
    public void execute() {

        previous.keySet().forEach(
            figure -> figure.setColor(color)
        );

        document.changed();
    }

    @Override
    public void undo() {

        previous.forEach(Figure::setColor);

        document.changed();
    }
}