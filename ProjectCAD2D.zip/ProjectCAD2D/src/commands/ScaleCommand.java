
package commands;

import figures.Figure;
import geometry.Point2;
import model.DrawingDocument;
import java.util.Objects;

public final class ScaleCommand implements Command {

    private final DrawingDocument document;
    private final Figure target;
    private final double factor;
    private final Point2 pivot;

    public ScaleCommand(DrawingDocument document,
                        Figure target,
                        double factor,
                        Point2 pivot) {

        this.document = Objects.requireNonNull(document);
        this.target = Objects.requireNonNull(target);
        this.pivot = Objects.requireNonNull(pivot);

        if (!Double.isFinite(factor) || factor <= 0) {
            throw new IllegalArgumentException("Invalid scale factor");
        }

        this.factor = factor;
    }

    @Override
    public void execute() {
        target.scale(factor, pivot);
    }

    @Override
    public void undo() {
        target.scale(1.0 / factor, pivot);
    }
}
