package app;

import model.DrawingDocument;
import model.Selection;
import tools.MoveTool;
import tools.ShapeTool;
import tools.RotateTool;
import tools.ScaleTool;
import commands.History;
import commands.GroupCommand;
import commands.ColorCommand;
import commands.ThicknessCommand;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;

public final class DrawingApp {

    private static Color color = Color.BLACK;
    private static float thickness = 1.0f;

    private static boolean canSplit(figures.Figure figure) {
        return !figure.parts().isEmpty();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            var document = new DrawingDocument(DemoContent.create());
            var selection = new Selection();
            var history = new History();
            var panel = new DrawingPanel(document, selection);
            JFrame frame = new JFrame("DVG345 - Projektuppgift");

            var toolbar = new JPanel();
            var status = new JLabel("Verktyg: Flytta");
            var drawingFiles = new DrawingFiles(document, selection, history, panel, frame);

            JMenuBar menuBar = new JMenuBar();
            JMenu fileMenu = new JMenu("Arkiv");

            JMenuItem newItem = new JMenuItem("Ny Ritning");
            JMenuItem openItem = new JMenuItem("Öppna...");
            JMenuItem saveItem = new JMenuItem("Spara");
            JMenuItem saveAsItem = new JMenuItem("Spara som...");
            JMenuItem exitItem = new JMenuItem("Avsluta");

            fileMenu.add(newItem);
            fileMenu.addSeparator();
            fileMenu.add(openItem);
            fileMenu.add(saveItem);
            fileMenu.add(saveAsItem);
            fileMenu.addSeparator();
            fileMenu.add(exitItem);
            menuBar.add(fileMenu);

            newItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
            openItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));
            saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
            saveAsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK));

            JButton move = new JButton("Flytta / markera");
            JButton circle = new JButton("Cirkel");
            JButton square = new JButton("Fyrkant");
            JButton rectangle = new JButton("Rektangel");
            JButton triangle = new JButton("Triangel");
            JButton line = new JButton("Linje");

            JButton rotate = new JButton("Rotera");
            JButton group = new JButton("Gruppera");
            JButton split = new JButton("Dela upp");
            JButton undo = new JButton("Ångra");
            JButton redo = new JButton("Gör om");
            // scale
            JButton scale = new JButton("Skala");

            scale.addActionListener(e -> {
                panel.setTool(new ScaleTool(document, selection, history));
                status.setText("Verktyg: Skala");
            });

            //Fäärg
            JButton colorButton = new JButton("Färg");

            JLabel colorPreview = new JLabel();
            colorPreview.setOpaque(true);
            colorPreview.setBackground(color);
            colorPreview.setPreferredSize(new Dimension(24, 24));
            colorPreview.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            colorPreview.setToolTipText("Aktuellt vald färg");

            //Färg
            colorButton.addActionListener(e -> {
                panel.cancelGesture();
                Color chosen = JColorChooser.showDialog(panel, "Välj färg", color);

                if (chosen != null) {
                    color = chosen;
                    colorPreview.setBackground(color);
                    if (!selection.figures().isEmpty()) {
                        history.execute(new ColorCommand(document, selection.figures(), color));
                    }
                    panel.setDrawingColor(color);
                    drawingFiles.refresh();
                }
            });

            JButton thicknessButton = new JButton("Linjetjocklek");
            JLabel thicknessPreview = new JLabel("1 px");
            thicknessButton.setToolTipText("Ändra linjetjocklek på figurer");

            thicknessButton.addActionListener(e -> {
                panel.cancelGesture();
                JSlider slider = new JSlider(1, 20, (int) thickness);
                slider.setMajorTickSpacing(5);
                slider.setMinorTickSpacing(1);
                slider.setPaintTicks(true);
                slider.setPaintLabels(true);
                slider.setSnapToTicks(true);

                JLabel valueLabel = new JLabel((int) thickness + " px");
                slider.addChangeListener(event -> valueLabel.setText(slider.getValue() + " px"));

                JPanel thicknessPanel = new JPanel(new BorderLayout());
                thicknessPanel.add(slider, BorderLayout.CENTER);
                thicknessPanel.add(valueLabel, BorderLayout.SOUTH);

                int result = JOptionPane.showConfirmDialog(panel, thicknessPanel, "Välj linjetjocklek", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    thickness = slider.getValue();
                    thicknessPreview.setText((int) thickness + " px");
                    if (!selection.figures().isEmpty()) {
                        history.execute(new ThicknessCommand(document, selection.figures(), thickness));
                    }
                    panel.setDrawingThickness(thickness);
                    drawingFiles.refresh();
                }
            });

            //FLYTTA/MARKERA
            move.addActionListener(e -> {
                panel.setTool(new MoveTool(document, selection, history));
                status.setText("Verktyg: Flytta");
            });

            //cirkel
            circle.addActionListener(e -> {
               selection.clear();
               panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.CIRCLE));
               status.setText("Verktyg: Cirkel");
            });

            //fyrkant
            square.addActionListener(e -> {
                selection.clear();
                panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.SQUARE));
                status.setText("Verktyg: Fyrkant");
            });

            //REKTANGEL
            rectangle.addActionListener(e -> {
                selection.clear();
                panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.RECTANGLE));
                status.setText("Verktyg: Rektangel");
            });

            //Triangel
            triangle.addActionListener(e -> {
                selection.clear();
                panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.TRIANGLE));
                status.setText("Verktyg: Triangel");
            });

            //LINJE
            line.addActionListener(e -> {
                selection.clear();
                panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.LINE));
                status.setText("Verktyg: Linje");
            });

            //roteraaa
            rotate.setToolTipText("Markera en figur och dra runt dess centrum. " + "Shift-klick markerar flera.");

            rotate.addActionListener(e -> {
                panel.setTool(new RotateTool(document, selection, history));
                status.setText("Rotera: dra runt markerade figurers centrum; " + "Shift-klick markerar flera. Esc avslutar.");
            });

            //group
            group.addActionListener(e -> {
                panel.cancelGesture();
                if (selection.figures().size() >= 2) {
                    history.execute(new GroupCommand(document, selection, false));
                }
                panel.repaint();
                drawingFiles.refresh();
            });

            //DELA UPP
            split.addActionListener(e -> {
                panel.cancelGesture();
                if (selection.figures().stream().anyMatch(DrawingApp::canSplit)) {
                    history.execute(new GroupCommand(document, selection, true));
                }
                panel.repaint();
                drawingFiles.refresh();
            });

            //undooo
            undo.addActionListener(e -> {
                panel.cancelGesture();
                history.undo();
                selection.clear();
                panel.repaint();
                drawingFiles.refresh();
            });

            //redooo
            redo.addActionListener(e -> {
                panel.cancelGesture();
                history.redo();
                selection.clear();
                panel.repaint();
                drawingFiles.refresh();
            });

            //ARKIVHÄNDELSER
            newItem.addActionListener(e -> drawingFiles.newDrawing());
            openItem.addActionListener(e -> drawingFiles.open());
            saveItem.addActionListener(e -> drawingFiles.save());
            saveAsItem.addActionListener(e -> drawingFiles.saveAs());
            exitItem.addActionListener(e -> drawingFiles.exit());

            //KNAPPAR
            toolbar.add(colorButton);
            toolbar.add(colorPreview);
            toolbar.add(thicknessButton);
            toolbar.add(thicknessPreview);

            toolbar.add(move);
            toolbar.add(circle);
            toolbar.add(square);
            toolbar.add(rectangle);
            toolbar.add(triangle);
            toolbar.add(line);

            toolbar.add(group);
            toolbar.add(split);
            toolbar.add(rotate);
            toolbar.add(scale);
            toolbar.add(undo);
            toolbar.add(redo);

            //standardverktyg
            panel.setTool(new MoveTool(document, selection, history));

            panel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseReleased(MouseEvent e) {
                    SwingUtilities.invokeLater(drawingFiles::refresh);
                }
            });

            //FÖNSTER
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    drawingFiles.exit();
                }
            });

            //MENYRAD OCH TOOLBAR
            JPanel topPanel = new JPanel(new BorderLayout());
            topPanel.add(menuBar, BorderLayout.NORTH);
            topPanel.add(toolbar, BorderLayout.SOUTH);

            frame.add(topPanel, BorderLayout.NORTH);
            frame.add(panel, BorderLayout.CENTER);
            frame.add(status, BorderLayout.SOUTH);

            frame.pack();
            frame.setLocationByPlatform(true);
            frame.setVisible(true);
        });
    }
}