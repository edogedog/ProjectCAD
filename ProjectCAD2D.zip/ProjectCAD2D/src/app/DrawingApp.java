
package app;

import model.DrawingDocument;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFileChooser;
import java.io.File;
import model.Selection;

import tools.MoveTool;
import tools.ShapeTool;
import tools.RotateTool;

import commands.History;
import commands.GroupCommand;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JColorChooser;
import javax.swing.BorderFactory;
import javax.swing.SwingUtilities;
import tools.ScaleTool;

public final class DrawingApp {

	private static Color color = Color.BLACK;

	private static boolean canSplit(figures.Figure figure) {
		return !figure.parts().isEmpty();
	}

	public static void main(String[] args) {

		SwingUtilities.invokeLater(() -> {

			var document = new DrawingDocument(DemoContent.create());
			var selection = new Selection();
			var history = new History();
			var panel = new DrawingPanel(document, selection);
			
			JFrame frame = new JFrame("DVG345 - Projektuppgift");

			var toolbar = new JPanel();
			var status = new JLabel("Verktyg: Flytta");

			JMenuBar menuBar = new JMenuBar();

			JMenu fileMenu = new JMenu("Arkiv");

			JMenuItem newItem = new JMenuItem("Ny Ritning");
			JMenuItem openItem = new JMenuItem("Öppna...");
			JMenuItem saveItem = new JMenuItem("Spara");
			JMenuItem saveAsItem = new JMenuItem("Spara som...");
			JMenuItem exitItem = new JMenuItem("Avsluta");

			fileMenu.add(newItem);
			fileMenu.addSeparator();
			fileMenu.add(openItem);
			fileMenu.add(saveItem);
			fileMenu.add(saveAsItem);
			fileMenu.addSeparator();
			fileMenu.add(exitItem);

			menuBar.add(fileMenu);

			JButton move = new JButton("Flytta / markera");
			JButton circle = new JButton("Cirkel");
			JButton square = new JButton("Fyrkant");
			JButton rectangle = new JButton("Rektangel");
			JButton triangle = new JButton("Triangel");
			JButton line = new JButton("Linje");

			JButton rotate = new JButton("Rotera");
			JButton group = new JButton("Gruppera");
			JButton split = new JButton("Dela upp");
			JButton undo = new JButton("Ångra");
			JButton redo = new JButton("Gör om");
			// scale
			JButton scale = new JButton("Skala");

			scale.addActionListener(e -> {
				panel.setTool(new ScaleTool(document, selection, history));
				status.setText("Verktyg: Skala");
			});
			// FÄRG
			JButton colorButton = new JButton("Färg");

			JLabel colorPreview = new JLabel();
			colorPreview.setOpaque(true);
			colorPreview.setBackground(color);
			colorPreview.setPreferredSize(new Dimension(24, 24));
			colorPreview.setBorder(BorderFactory.createLineBorder(Color.GRAY));
			colorPreview.setToolTipText("Aktuellt vald färg");

			// FÄRG
			colorButton.addActionListener(e -> {
				Color chosen = JColorChooser.showDialog(panel, "Välj färg", color);

				if (chosen != null) {
					color = chosen;
					colorPreview.setBackground(color);
				}
			});

			// FLYTTA / MARKERA
			move.addActionListener(e -> {
				panel.setTool(new MoveTool(document, selection, history));
				status.setText("Verktyg: Flytta");
			});

			// CIRKEL
			circle.addActionListener(e -> {
				panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.CIRCLE));
				status.setText("Verktyg: Cirkel");
			});

			// FYRKANT
			square.addActionListener(e -> {
				panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.SQUARE));
				status.setText("Verktyg: Fyrkant");
			});

			// REKTANGEL
			rectangle.addActionListener(e -> {
				panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.RECTANGLE));
				status.setText("Verktyg: Rektangel");
			});

			// TRIANGEL
			triangle.addActionListener(e -> {
				panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.TRIANGLE));
				status.setText("Verktyg: Triangel");
			});

			// LINJE
			line.addActionListener(e -> {
				panel.setTool(new ShapeTool(document, history, ShapeTool.Shape.LINE));
				status.setText("Verktyg: Linje");
			});

			// ROTERA
			rotate.setToolTipText("Markera en figur och dra runt dess centrum. " + "Shift-klick markerar flera.");

			rotate.addActionListener(e -> {
				panel.setTool(new RotateTool(document, selection, history));
				status.setText(
						"Rotera: dra runt markerade figurers centrum; " + "Shift-klick markerar flera. Esc avslutar.");
			});

			// GRUPPERA
			group.addActionListener(e -> {
				panel.cancelGesture();

				if (selection.figures().size() >= 2) {
					history.execute(new GroupCommand(document, selection, false));
				}

				panel.repaint();
			});

			// DELA UPP
			split.addActionListener(e -> {
				panel.cancelGesture();

				if (selection.figures().stream().anyMatch(DrawingApp::canSplit)) {
					history.execute(new GroupCommand(document, selection, true));
				}

				panel.repaint();
			});

			// ÅNGRA
			undo.addActionListener(e -> {
				panel.cancelGesture();
				history.undo();
				selection.clear();
				panel.repaint();
			});

			// GÖR OM
			redo.addActionListener(e -> {
				panel.cancelGesture();
				history.redo();
				selection.clear();
				panel.repaint();
			});

			// ARKIV - HÄNDELSER

			JFileChooser chooser = new JFileChooser();

			newItem.addActionListener(e -> {
				panel.cancelGesture();
				selection.clear();
				panel.repaint();
			});

			openItem.addActionListener(e -> {
				int result = chooser.showOpenDialog(frame);

				if (result == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
				}
			});

			saveItem.addActionListener(e -> {

			});

			saveAsItem.addActionListener(e -> {
				int result = chooser.showSaveDialog(frame);

				if (result == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
				}
			});

			exitItem.addActionListener(e -> {
				frame.dispose();
			});

			// KNAPPAR
			toolbar.add(colorButton);
			toolbar.add(colorPreview);

			toolbar.add(move);
			toolbar.add(circle);
			toolbar.add(square);
			toolbar.add(rectangle);
			toolbar.add(triangle);
			toolbar.add(line);

			toolbar.add(group);
			toolbar.add(split);
			toolbar.add(rotate);
			toolbar.add(scale);
			toolbar.add(undo);
			toolbar.add(redo);

			// STANDARDVERKTYG
			panel.setTool(new MoveTool(document, selection, history));

			// FÖNSTER

			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			// MENYRAD OCH TOOLBAR
			JPanel topPanel = new JPanel(new BorderLayout());

			topPanel.add(menuBar, BorderLayout.NORTH);
			topPanel.add(toolbar, BorderLayout.SOUTH);

			frame.add(topPanel, BorderLayout.NORTH);
			frame.add(panel, BorderLayout.CENTER);
			frame.add(status, BorderLayout.SOUTH);

			frame.pack();
			frame.setLocationByPlatform(true);
			frame.setVisible(true);
		});
	}
}
