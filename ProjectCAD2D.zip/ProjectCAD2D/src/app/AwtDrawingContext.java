package app;

import geometry.Point2;
import rendering.DrawingContext;

import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.Stroke;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;

import java.util.Objects;
import java.util.List;

public final class AwtDrawingContext implements DrawingContext {

    private final Graphics2D graphics;
    private Color overrideColor;

    public AwtDrawingContext(Graphics2D graphics) {

        this.graphics = Objects.requireNonNull(graphics);
    }

    public AwtDrawingContext(Graphics2D graphics,
                             Color overrideColor) {

        this(graphics);
        this.overrideColor = overrideColor;
    }

    @Override
    public void line(Point2 start, Point2 end) {

        graphics.draw(new Line2D.Double(
            start.x(),
            start.y(),
            end.x(),
            end.y()
        ));
    }

    @Override
    public void circle(Point2 center, double radius) {

        graphics.draw(new Ellipse2D.Double(
            center.x() - radius,
            center.y() - radius,
            2 * radius,
            2 * radius
        ));
    }

    @Override
    public void polygon(List<Point2> vertices) {

        var points = List.copyOf(vertices);

        if (points.size() < 3) {
            throw new IllegalArgumentException();
        }

        var path = new Path2D.Double();

        path.moveTo(
            points.get(0).x(),
            points.get(0).y()
        );

        for (int i = 1; i < points.size(); i++) {

            path.lineTo(
                points.get(i).x(),
                points.get(i).y()
            );
        }

        path.closePath();

        graphics.draw(path);
    }

    private void drawStyled(Color color,
                            float thickness,
                            Runnable drawing) {

        Color oldColor = graphics.getColor();
        Stroke oldStroke = graphics.getStroke();

        try {

            if (overrideColor != null) {

                graphics.setColor(overrideColor);

            } else {

                graphics.setColor(color);

                graphics.setStroke(new BasicStroke(
                    thickness,
                    BasicStroke.CAP_ROUND,
                    BasicStroke.JOIN_ROUND
                ));
            }

            drawing.run();

        } finally {

            graphics.setColor(oldColor);
            graphics.setStroke(oldStroke);
        }
    }

    @Override
    public void circle(Point2 center,
                       double radius,
                       Color color) {

        circle(center, radius, color, 1.0f);
    }

    @Override
    public void line(Point2 start,
                     Point2 end,
                     Color color) {

        line(start, end, color, 1.0f);
    }

    @Override
    public void polygon(List<Point2> vertices,
                        Color color) {

        polygon(vertices, color, 1.0f);
    }

    @Override
    public void circle(Point2 center,
                       double radius,
                       Color color,
                       float thickness) {

        drawStyled(color, thickness, () -> {
            circle(center, radius);
        });
    }

    @Override
    public void line(Point2 start,
                     Point2 end,
                     Color color,
                     float thickness) {

        drawStyled(color, thickness, () -> {
            line(start, end);
        });
    }

    @Override
    public void polygon(List<Point2> vertices,
                        Color color,
                        float thickness) {

        drawStyled(color, thickness, () -> {
            polygon(vertices);
        });
    }
}