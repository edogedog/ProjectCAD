package app;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import figures.Figure;
import model.DrawingDocument;
import model.Selection;
import commands.History;

public final class DrawingFiles {
    private final DrawingDocument document;
    private final Selection selection;
    private final History history;
    private final DrawingPanel panel;
    private final JFrame frame;
    private final JFileChooser chooser = new JFileChooser();
    private File currentFile;
    private byte[] savedState;

    public DrawingFiles(DrawingDocument document, Selection selection, History history, DrawingPanel panel, JFrame frame) {
        this.document = document;
        this.selection = selection;
        this.history = history;
        this.panel = panel;
        this.frame = frame;

        chooser.setFileFilter(new FileNameExtensionFilter("CAD-ritning (*.cad2d)", "cad2d"));
        chooser.setAcceptAllFileFilterUsed(false);

        try {
            savedState = snapshot();
        } catch (IOException e) {
            showError(e);
        }
        document.addListener(this::updateTitle);
        updateTitle();
    }

    private byte[] snapshot() throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream output = new ObjectOutputStream(bytes)) {
            output.writeObject(new ArrayList<>(document.figures()));
        }
        return bytes.toByteArray();
    }

    //jämför ritningen med senast sparade versionen
    public boolean hasUnsavedChanges() {
        try {
            return !Arrays.equals(savedState, snapshot());
        } catch (IOException e) {
            return true;
        }
    }

    private void updateTitle() {
        String name = currentFile == null ? "Namnlös ritning" : currentFile.getName();
        String changed = hasUnsavedChanges() ? " *" : "";
        frame.setTitle("DVG345 - " + name + changed);
    }

    private boolean confirmChanges() {
        if (!hasUnsavedChanges()) {
            return true;
        }
        String[] options = {"Spara", "Spara inte", "Avbryt"};
        int choice = JOptionPane.showOptionDialog(frame,
                "Du har osparade ändringar. Vill du spara?",
                "Osparade ändringar",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            return save();
        }
        return choice == 1;
    }

    public void newDrawing() {
        panel.cancelGesture();
        if (!confirmChanges()) {
            return;
        }
        //töm gamla ritningen och history
        selection.clear();
        history.clear();
        document.replace(List.of());
        currentFile = null;

        try {
            savedState = snapshot();
        } catch (IOException e) {
            showError(e);
        }
        updateTitle();
        panel.repaint();
    }

    public boolean save() {
        panel.cancelGesture();
        if (currentFile == null) {
            return saveAs();
        }
        return writeFile(currentFile);
    }

    public boolean saveAs() {
        panel.cancelGesture();
        chooser.setSelectedFile(currentFile == null ? new File("Ritning.cad2d") : currentFile);
        int result = chooser.showSaveDialog(frame);

        if (result != JFileChooser.APPROVE_OPTION) {
            return false;
        }
        File file = chooser.getSelectedFile();

        if (!file.getName().toLowerCase().endsWith(".cad2d")) {
            file = new File(file.getAbsolutePath() + ".cad2d");
        }
        if (file.exists()) {
            int overwrite = JOptionPane.showConfirmDialog(frame,
                    "Filen finns redan. Vill du ersätta den?",
                    "Ersätt fil", JOptionPane.YES_NO_OPTION);
            if (overwrite != JOptionPane.YES_OPTION) {
                return false;
            }
        }
        return writeFile(file);
    }

    private boolean writeFile(File file) {
        Path temporaryFile = null;
        try {
            byte[] data = snapshot();
            Path destination = file.toPath().toAbsolutePath();

            //spara till en temporär fil först 
            temporaryFile = Files.createTempFile(destination.getParent(), "drawing-", ".tmp");
            Files.write(temporaryFile, data);

            try {
                Files.move(temporaryFile, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temporaryFile, destination, StandardCopyOption.REPLACE_EXISTING);
            }
            currentFile = file;
            savedState = data;
            updateTitle();
            return true;

        } catch (IOException e) {
            showError(e);
            return false;
        } finally {
            if (temporaryFile != null) {
                try {
                    Files.deleteIfExists(temporaryFile);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public void open() {
        panel.cancelGesture();
        if (!confirmChanges()) {
            return;
        }
        int result = chooser.showOpenDialog(frame);
        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();

        try {
            List<Figure> loadedFigures = readFile(file);
            //kontrollera den nya ritningen innan den gamla ersätts
            new DrawingDocument(loadedFigures);
            selection.clear();
            history.clear();
            document.replace(loadedFigures);
            currentFile = file;
            savedState = snapshot();
            updateTitle();
            panel.repaint();

        } catch (IOException | ClassNotFoundException | RuntimeException e) {
            showError(e);
        }
    }

    private List<Figure> readFile(File file) throws IOException, ClassNotFoundException {
        if (Files.size(file.toPath()) > 20000000) {
            throw new IOException("Filen är för stor");
        }
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(file))) {
            //tillåt bara klasser som behövs för ritningen ellerr teckningen
            input.setObjectInputFilter(info -> {
                if (info.depth() > 100 || info.references() > 200000 ||
                        info.arrayLength() > 200000 || info.streamBytes() > 20000000) {
                    return ObjectInputFilter.Status.REJECTED;
                }
                Class<?> type = info.serialClass();
                if (type == null) {
                    return ObjectInputFilter.Status.UNDECIDED;
                }
                while (type.isArray()) {
                    type = type.getComponentType();
                }
                if (type.isPrimitive()) {
                    return ObjectInputFilter.Status.ALLOWED;
                }
                return switch (type.getName()) {
                    case "figures.Circle", "figures.Rectangle",
                         "figures.Square", "figures.Triangle",
                         "figures.Line", "figures.CompositeFigure",
                         "geometry.Point2", "java.awt.Color",
                         "java.util.ArrayList", "java.util.CollSer",
                         "java.util.ImmutableCollections$List12",
                         "java.util.ImmutableCollections$ListN",
                         "java.lang.Object" -> ObjectInputFilter.Status.ALLOWED;
                    default -> ObjectInputFilter.Status.REJECTED;
                };
            });

            Object object = input.readObject();
            if (!(object instanceof List<?> list)) {
                throw new IOException("Ogiltig ritning");
            }

            List<Figure> figures = new ArrayList<>();
            for (Object item : list) {
                if (!(item instanceof Figure figure)) {
                    throw new IOException("Ogiltig figur");
                }
                validateFigure(figure);
                figures.add(figure);
            }
            return figures;
        }
    }

    private void validateFigure(Figure figure) throws IOException {
        if (figure.getCenter() == null || figure.getColor() == null ||
                !Float.isFinite(figure.getThickness()) || figure.getThickness() <= 0) {
            throw new IOException("Ogiltiga figuregenskaper");
        }
        // kolla även figurerna inuti grupperna
        for (Figure child : figure.parts()) {
            validateFigure(child);
        }
    }

    public void exit() {
        panel.cancelGesture();
        if (confirmChanges()) {
            frame.dispose();
        }
    }

    public void refresh() {
        updateTitle();
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(frame, e.getMessage(),
                "Filhanteringsfel", JOptionPane.ERROR_MESSAGE);
    }
}