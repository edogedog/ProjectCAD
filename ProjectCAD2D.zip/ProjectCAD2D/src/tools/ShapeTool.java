package tools;

import figures.*;
import commands.History;
import commands.AddCommand;
import geometry.Point2;
import model.DrawingDocument;
import rendering.DrawingContext;

import java.awt.Color;
import java.util.Objects;

public final class ShapeTool implements Tool {

    public enum Shape {
        CIRCLE, SQUARE, RECTANGLE, TRIANGLE, LINE
    }

    private final DrawingDocument document;
    private final History history;
    private final Shape shape;

    private Color color = Color.BLACK;
    private float thickness = 1.0f;

    private Point2 start;
    private Point2 end;

    public ShapeTool(DrawingDocument document,
                     History history,
                     Shape shape) {

        this.document = document;
        this.history = history;
        this.shape = shape;
    }

    public void setColor(Color color) {
        this.color = Objects.requireNonNull(color);
    }

    public void setThickness(float thickness) {

        if (!Float.isFinite(thickness) || thickness <= 0) {
            throw new IllegalArgumentException();
        }

        this.thickness = thickness;
    }

    @Override
    public void pressed(Point2 point, boolean extend) {

        start = point;
        end = point;
    }

    @Override
    public void dragged(Point2 point) {
        end = point;
    }

    @Override
    public void released(Point2 point) {

        if (start != null) {

            end = point;

            Figure figure = createFigure();

            if (figure != null) {

                figure.setColor(color);
                figure.setThickness(thickness);

                history.execute(
                    new AddCommand(document, figure)
                );
            }
        }

        cancel();
    }

    private Figure createFigure() {

        if (start == null || end == null) {
            return null;
        }

        double width = Math.abs(end.x() - start.x());
        double height = Math.abs(end.y() - start.y());

        double side = Math.max(width, height);

        Point2 topLeft = new Point2(
            Math.min(start.x(), end.x()),
            Math.min(start.y(), end.y())
        );

        switch (shape) {

            case CIRCLE:

                double radius = start.distance(end);

                return radius > 0
                    ? new Circle(start, radius)
                    : null;

            case SQUARE:

                return side > 0
                    ? new Square(topLeft, side)
                    : null;

            case RECTANGLE:

                return width > 0 && height > 0
                    ? new Rectangle(topLeft, width, height)
                    : null;

            case TRIANGLE:

                return side > 0
                    ? new Triangle(topLeft, side)
                    : null;

            case LINE:

                return start.distance(end) > 0
                    ? new Line(start, end)
                    : null;

            default:
                return null;
        }
    }

    @Override
    public void drawPreview(DrawingContext context) {

        Figure preview = createFigure();

        if (preview != null) {

            preview.setColor(color);
            preview.setThickness(thickness);
            preview.draw(context);
        }
    }

    @Override
    public void cancel() {

        start = null;
        end = null;
    }
}