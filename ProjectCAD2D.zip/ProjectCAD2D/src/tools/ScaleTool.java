
package tools;

import commands.History;
import commands.ScaleCommand;
import geometry.Point2;
import model.DrawingDocument;
import model.Selection;
import rendering.DrawingContext;
import java.util.List;

public final class ScaleTool implements Tool {

    private final DrawingDocument document;
    private final History history;
    private final RotationGesture gesture;

    private Point2 start;
    private Point2 end;

    public ScaleTool(DrawingDocument document,
                     Selection selection,
                     History history) {

        this.document = document;
        this.history = history;
        this.gesture = new RotationGesture(document, selection);
    }

    @Override
    public void pressed(Point2 point, boolean extend) {
        gesture.begin(point, extend);

        if (gesture.active()) {
            start = point;
            end = point;
        }
    }

    @Override
    public void dragged(Point2 point) {
        if (!gesture.active()) return;

        end = point;
        gesture.advance(point);
    }

    @Override
    public void released(Point2 point) {
        if (!gesture.active()) return;

        end = point;
        gesture.advance(point);

        var target = gesture.target();
        var pivot = gesture.pivot();

        double factor = getFactor(pivot);

        cancel();

        if (Double.isFinite(factor) && factor > 0 && factor != 1.0) {
            history.execute(
                new ScaleCommand(document, target, factor, pivot)
            );
        }
    }

    @Override
    public void cancel() {
        gesture.cancel();
        start = null;
        end = null;
    }

    private double getFactor(Point2 pivot) {

        if (start == null || end == null) {
            return 1.0;
        }

        double startDistance = start.distance(pivot);
        double endDistance = end.distance(pivot);

        if (startDistance <= 0 || !Double.isFinite(startDistance)) {
            return 1.0;
        }

        double factor = endDistance / startDistance;

        if (!Double.isFinite(factor) || factor <= 0) {
            return 1.0;
        }

        return factor;
    }

    @Override
    public void drawPreview(DrawingContext context) {

        if (!gesture.active() || start == null || end == null) {
            return;
        }

        var pivot = gesture.pivot();
        double factor = getFactor(pivot);

        gesture.target().draw(new DrawingContext() {

            @Override
            public void line(Point2 a, Point2 b) {
                context.line(
                    scalePoint(a, pivot, factor),
                    scalePoint(b, pivot, factor)
                );
            }

            @Override
            public void circle(Point2 center, double radius) {
                context.circle(
                    scalePoint(center, pivot, factor),
                    radius * factor
                );
            }

            @Override
            public void polygon(List<Point2> vertices) {
                context.polygon(
                    vertices.stream()
                        .map(p -> scalePoint(p, pivot, factor))
                        .toList()
                );
            }
        });

        gesture.drawGuide(context);
    }

    private Point2 scalePoint(Point2 point,
                              Point2 pivot,
                              double factor) {

        double newX = pivot.x()
                + (point.x() - pivot.x()) * factor;

        double newY = pivot.y()
                + (point.y() - pivot.y()) * factor;

        return new Point2(newX, newY);
    }
}
